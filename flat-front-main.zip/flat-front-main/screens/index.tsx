import Home from "./Home";
import Profile from "./Profile";
import Notifications from "./Notifications";
import Carteira from "./Carteira";
import Definicoes from "./Definicoes";

export {
    Home,
    Profile,
    Notifications,
    Carteira,
    Definicoes
}
