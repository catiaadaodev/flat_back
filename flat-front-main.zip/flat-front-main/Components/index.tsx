import Header from "./Header";
import ForYou from "./ForYou";
import PickUp  from './PickUp'
import Cartao from "./Cartao";
import Collector from "./Despesa";
import RadioButton from "./RadioButton";
import Pagamento from "./Pagammento";



export {
    Cartao,
    Header,
    ForYou,
    PickUp,
    Collector,
    RadioButton,
    Pagamento
}